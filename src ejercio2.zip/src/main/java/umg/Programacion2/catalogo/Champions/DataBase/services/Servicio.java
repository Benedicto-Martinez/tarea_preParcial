package umg.Programacion2.catalogo.Champions.DataBase.services;

import umg.Programacion2.catalogo.Champions.DataBase.Dao.Dao;
import umg.Programacion2.catalogo.Champions.DataBase.Modelo.Modelo;

import java.util.List;

public class Servicio {
    private Dao equipoDAO;

    public Servicio(Dao equipoDAO) {
        this.equipoDAO = equipoDAO;
    }

    public boolean agregarEquipo(Modelo equipo) {
        return equipoDAO.insertarEquipo(equipo);
    }

    public List<Modelo> listarEquipos() {
        return equipoDAO.obtenerEquipos();
    }

    public boolean modificarEquipo(Modelo equipo) {
        return equipoDAO.actualizarEquipo(equipo);
    }

    public boolean eliminarEquipo(int idEquipo) {
        return equipoDAO.eliminarEquipo(idEquipo);
    }
}

