package umg.Programacion2.catalogo.Champions;

import umg.Programacion2.catalogo.Champions.DataBase.Dao.Dao;
import umg.Programacion2.catalogo.Champions.DataBase.Modelo.Modelo;
import umg.Programacion2.catalogo.Champions.DataBase.services.Servicio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class cataChampions {
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JTextField textField8;
    private JTextField textField9;
    private JTextField textField10;
    private JButton buttonBuscar;
    private JButton buttonAnadir;
    private JButton buttonSalir;
    private JButton buttonEliminar;

    private Dao equipoDAO;
    private Servicio equipoServicio;

    public cataChampions(JTextField textField1) {
        this.textField1 = textField1;

        // Conexión a la base de datos
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tu_base_de_datos", "usuario", "contraseña");
            equipoDAO = new Dao(connection);
            equipoServicio = new Servicio(equipoDAO);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error conectando a la base de datos: " + e.getMessage());
        }

        // Asignar acciones a los botones
        buttonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarEquipo();
            }
        });

        buttonAnadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                añadirEquipo();
            }
        });

        buttonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarEquipo();
            }
        });

        buttonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    // Método para buscar equipos
    private void buscarEquipo() {
        List<Modelo> equipos = equipoServicio.listarEquipos();
        if (equipos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontraron equipos.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Modelo equipo : equipos) {
                sb.append(equipo.getNombre()).append(" - ").append(equipo.getPais()).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Método para añadir un equipo
    private void añadirEquipo() {
        String nombre = textField1.getText();
        String pais = textField2.getText();
        String ciudad = textField3.getText();
        String estadio = textField4.getText();
        int fundacion = Integer.parseInt(textField5.getText());
        String entrenador = textField6.getText();
        String webOficial = textField7.getText();
        String facebook = textField8.getText();
        String twitter = textField9.getText();
        String instagram = textField10.getText();

        Modelo equipo = new Modelo();
        equipo.setNombre(nombre);
        equipo.setPais(pais);
        equipo.setCiudad(ciudad);
        equipo.setEstadio(estadio);
        equipo.setFundacion(fundacion);
        equipo.setEntrenador(entrenador);
        equipo.setWebOficial(webOficial);
        equipo.setFacebook(facebook);
        equipo.setTwitter(twitter);
        equipo.setInstagram(instagram);

        boolean añadido = equipoServicio.agregarEquipo(equipo);
        if (añadido) {
            JOptionPane.showMessageDialog(null, "Equipo añadido con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "Error al añadir el equipo.");
        }
    }

    // Método para eliminar un equipo
    private void eliminarEquipo() {
        String idStr = JOptionPane.showInputDialog(null, "Introduce el ID del equipo a eliminar:");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            boolean eliminado = equipoServicio.eliminarEquipo(id);
            if (eliminado) {
                JOptionPane.showMessageDialog(null, "Equipo eliminado con éxito.");
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar el equipo.");
            }
        }
    }

    // Método principal para probar la interfaz
    public static void main(String[] args) {
        // Crear la ventana de la aplicación
        JFrame frame = new JFrame("Catalogo de Equipos de Champions");
        cataChampions catalogo = new cataChampions(new JTextField());
        frame.setContentPane(new JPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
