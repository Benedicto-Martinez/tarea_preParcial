package umg.Programacion2.catalogo.Champions.DataBase.Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion {


        private static final String URL = "jdbc:mysql://localhost:3306/ejecicio2preparcial"; // Cambia "tu_base_de_datos" por el nombre de tu base de datos
        private static final String USER = "root"; // Cambia "root" por tu usuario de base de datos
        private static final String PASSWORD = "destruc10"; // Cambia "" por tu contraseña de base de datos

        public static Connection getConnection() throws SQLException {
                try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        return DriverManager.getConnection(URL, USER, PASSWORD);
                } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                        throw new SQLException("Error al cargar el driver JDBC.");
                }
        }
}

