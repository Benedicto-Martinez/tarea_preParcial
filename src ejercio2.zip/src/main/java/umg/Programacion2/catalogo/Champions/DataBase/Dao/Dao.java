package umg.Programacion2.catalogo.Champions.DataBase.Dao;

import umg.Programacion2.catalogo.Champions.DataBase.Modelo.Modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Dao {
    private Connection connection;

    public Dao(Connection connection) {
        this.connection = connection;
    }

    // Insertar un equipo
    public boolean insertarEquipo(Modelo equipo) {
        String query = "INSERT INTO equipos_champions (nombre, pais, ciudad, estadio, fundacion, entrenador, web_oficial, facebook, twitter, instagram, patrocinador_principal) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, equipo.getNombre());
            ps.setString(2, equipo.getPais());
            ps.setString(3, equipo.getCiudad());
            ps.setString(4, equipo.getEstadio());
            ps.setInt(5, equipo.getFundacion());
            ps.setString(6, equipo.getEntrenador());
            ps.setString(7, equipo.getWebOficial());
            ps.setString(8, equipo.getFacebook());
            ps.setString(9, equipo.getTwitter());
            ps.setString(10, equipo.getInstagram());
            ps.setString(11, equipo.getPatrocinadorPrincipal());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Obtener todos los equipos
    public List<Modelo> obtenerEquipos() {
        List<Modelo> equipos = new ArrayList<>();
        String query = "SELECT * FROM equipos_champions";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Modelo equipo = new Modelo(
                        rs.getInt("id_equipo"),
                        rs.getString("nombre"),
                        rs.getString("pais"),
                        rs.getString("ciudad"),
                        rs.getString("estadio"),
                        rs.getInt("fundacion"),
                        rs.getString("entrenador"),
                        rs.getString("web_oficial"),
                        rs.getString("facebook"),
                        rs.getString("twitter"),
                        rs.getString("instagram"),
                        rs.getString("patrocinador_principal"),
                        rs.getString("creado_en")
                );
                equipos.add(equipo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return equipos;
    }

    // Actualizar un equipo
    public boolean actualizarEquipo(Modelo equipo) {
        String query = "UPDATE equipos_champions SET nombre=?, pais=?, ciudad=?, estadio=?, fundacion=?, entrenador=?, web_oficial=?, facebook=?, twitter=?, instagram=?, patrocinador_principal=? WHERE id_equipo=?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, equipo.getNombre());
            ps.setString(2, equipo.getPais());
            ps.setString(3, equipo.getCiudad());
            ps.setString(4, equipo.getEstadio());
            ps.setInt(5, equipo.getFundacion());
            ps.setString(6, equipo.getEntrenador());
            ps.setString(7, equipo.getWebOficial());
            ps.setString(8, equipo.getFacebook());
            ps.setString(9, equipo.getTwitter());
            ps.setString(10, equipo.getInstagram());
            ps.setString(11, equipo.getPatrocinadorPrincipal());
            ps.setInt(12, equipo.getIdEquipo());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Eliminar un equipo
    public boolean eliminarEquipo(int idEquipo) {
        String query = "DELETE FROM equipos_champions WHERE id_equipo = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, idEquipo);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
